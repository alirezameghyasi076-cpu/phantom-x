package com.vauth.foxyvpn.vpn.upstream

import java.io.InterruptedIOException
import java.net.SocketTimeoutException

class UpstreamHealthTracker {

    enum class Verdict {

        TARGET_FAILURE,

        SESSION_UNHEALTHY,

        SESSION_UNAUTHENTICATED,
    }

    private val timeoutTargets = LinkedHashSet<String>()

    private val forbiddenTargets = LinkedHashSet<String>()

    @Synchronized
    fun observeSuccess() {
        timeoutTargets.clear()
        forbiddenTargets.clear()
    }

    @Synchronized
    fun reset() {
        timeoutTargets.clear()
        forbiddenTargets.clear()
    }

    @Synchronized
    fun observeFailure(target: String, cause: Throwable?): Verdict {

        if (invalidatesSession(cause)) {
            timeoutTargets.clear()
            forbiddenTargets.clear()
            return Verdict.SESSION_UNAUTHENTICATED
        }

        // A single 403 usually means the edge refuses that one destination, not that our pass is bad.
        // Only when several unrelated destinations are refused in a row, with no success between them,
        // is the pass itself the likelier cause; until then a refused site must not take the whole
        // tunnel down (every other site would then fail until the next redial).
        if ((cause as? UpstreamConnectRejectedException)?.statusCode == STATUS_FORBIDDEN) {
            forbiddenTargets.add(target)
            if (forbiddenTargets.size < MAX_DISTINCT_FORBIDDEN_TARGETS) return Verdict.TARGET_FAILURE
            forbiddenTargets.clear()
            timeoutTargets.clear()
            return Verdict.SESSION_UNAUTHENTICATED
        }

        if (!isSilence(cause)) return Verdict.TARGET_FAILURE

        timeoutTargets.add(target)
        if (timeoutTargets.size < MAX_DISTINCT_TIMEOUT_TARGETS) return Verdict.TARGET_FAILURE

        timeoutTargets.clear()
        return Verdict.SESSION_UNHEALTHY
    }

    private fun isSilence(cause: Throwable?): Boolean = when (cause) {
        null -> true
        is UpstreamConnectTimeoutException -> true
        is SocketTimeoutException -> true
        is InterruptedIOException -> true
        else -> false
    }

    private fun invalidatesSession(cause: Throwable?): Boolean {
        val rejection = cause as? UpstreamConnectRejectedException ?: return false
        return rejection.statusCode in SESSION_FATAL_STATUS_CODES
    }

    companion object {

        const val MAX_DISTINCT_TIMEOUT_TARGETS = 10

        const val MAX_DISTINCT_FORBIDDEN_TARGETS = 4

        const val STATUS_FORBIDDEN = 403

        val SESSION_FATAL_STATUS_CODES = setOf(401, 407)

        val TARGET_UNREACHABLE_STATUS_CODES = setOf(502, 503, 504)
    }
}

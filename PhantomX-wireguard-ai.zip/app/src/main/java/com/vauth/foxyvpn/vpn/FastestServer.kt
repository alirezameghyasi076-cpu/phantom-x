package com.vauth.foxyvpn.vpn

import com.vauth.foxyvpn.data.ServerListClient
import com.vauth.foxyvpn.data.model.ProxyCandidate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

private const val SERVER_LIST_TIMEOUT_MS = 15_000L
private const val MAX_PARALLEL_PINGS = 16

data class FastestServerPick(
    val candidate: ProxyCandidate,
    val latencyMs: Int,
)

/**
 * Pings one server per city in every country and returns the quickest one that answered.
 * Run it while disconnected: the pings are plain TCP connects from the phone.
 */
object FastestServer {

    suspend fun find(client: ServerListClient): FastestServerPick? = withContext(Dispatchers.IO) {
        val countries = runCatching {
            withTimeout(SERVER_LIST_TIMEOUT_MS) { client.fetchCountries() }
        }.getOrElse { client.loadCachedCountries() }

        val candidates = countries
            .flatMap { country -> ServerListClient.candidatesForCountry(countries, country.code) }
            .distinctBy { it.countryCode.lowercase() + "/" + it.cityCode.lowercase() }
        if (candidates.isEmpty()) return@withContext null

        val gate = Semaphore(MAX_PARALLEL_PINGS)
        val results = coroutineScope {
            candidates.map { candidate ->
                async {
                    gate.withPermit { candidate to PingUtil.measureTcpLatencyMs(candidate.host, candidate.port) }
                }
            }.awaitAll()
        }

        var best: FastestServerPick? = null
        for ((candidate, latency) in results) {
            if (latency == null) continue
            val current = best
            if (current == null || latency < current.latencyMs) {
                best = FastestServerPick(candidate, latency)
            }
        }
        best
    }
}

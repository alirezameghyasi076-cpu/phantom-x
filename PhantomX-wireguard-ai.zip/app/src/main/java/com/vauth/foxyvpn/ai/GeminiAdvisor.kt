package com.vauth.foxyvpn.ai

import com.vauth.foxyvpn.BuildConfig
import com.vauth.foxyvpn.data.AppLogger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * Built-in AI advisor (Google Gemini). The key is baked in at build time from the
 * GEMINI_API_KEY build secret; there is no setting in the app to view or change it.
 */
object GeminiAdvisor {

    private const val TAG = "GeminiAdvisor"
    private const val MODEL = "gemini-2.5-flash"
    private const val URL =
        "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"
    private const val MIN_GAP_MS = 3_000L
    private const val MAX_INPUT_CHARS = 1_500

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    private val json = Json { ignoreUnknownKeys = true }

    @Volatile private var lastCallAt = 0L

    /** Strings that mean the text holds a secret (config, link, key). Such text is never sent. */
    private val secretMarkers = listOf(
        "privatekey", "presharedkey", "vless://", "vmess://", "trojan://", "ss://",
        "hysteria2://", "hy2://", "tuic://", "wireguard://", "wg://", "-----begin",
    )

    private const val SYSTEM_PROMPT = """
You are the built-in advisor of Phantom X, an Android VPN app. The app can run: its own Phantom X VPN,
Cloudflare WARP, WireGuard profiles, and share-link protocols (Shadowsocks, Hysteria2, TUIC, Trojan,
VLESS incl. Reality, VMess) on a sing-box core. Help the user choose the right protocol and settings,
fix slow or blocked connections (MTU, port 443, endpoint choice, DNS, UDP vs TCP, Reality vs plain TLS),
and explain things simply. Be honest: you cannot provide servers or configs, you cannot test the user's
network, and you must not invent server addresses, keys, links or speed numbers. If something depends on
the user's server or network, say what to check. Never ask the user to paste a private key, password or
full config. Answer in the language the user writes in (Persian if they write Persian). Keep answers short,
practical and step by step, with at most about 12 lines.
"""

    sealed class Result {
        data class Ok(val text: String) : Result()
        data class Fail(val message: String) : Result()
    }

    val available: Boolean get() = BuildConfig.GEMINI_API_KEY.isNotBlank()

    suspend fun ask(question: String): Result {
        val q = question.trim()
        if (q.isEmpty()) return Result.Fail("Type a question first.")
        if (!available) return Result.Fail("The AI advisor is not set up in this build.")
        val lower = q.lowercase()
        if (secretMarkers.any { lower.contains(it) }) {
            return Result.Fail("Please don't paste configs, links or keys here. They contain secrets. Describe the problem in words instead.")
        }
        val now = System.currentTimeMillis()
        if (now - lastCallAt < MIN_GAP_MS) return Result.Fail("Please wait a few seconds and ask again.")
        lastCallAt = now

        val body = buildJsonObject {
            put("system_instruction", buildJsonObject {
                put("parts", buildJsonArray { add(buildJsonObject { put("text", SYSTEM_PROMPT.trim()) }) })
            })
            put("contents", buildJsonArray {
                add(buildJsonObject {
                    put("role", "user")
                    put("parts", buildJsonArray {
                        add(buildJsonObject { put("text", q.take(MAX_INPUT_CHARS)) })
                    })
                })
            })
            put("generationConfig", buildJsonObject {
                put("temperature", 0.4)
                put("maxOutputTokens", 900)
            })
        }.toString()

        return withContext(Dispatchers.IO) {
            try {
                val req = Request.Builder()
                    .url(URL)
                    .header("x-goog-api-key", BuildConfig.GEMINI_API_KEY)
                    .post(body.toRequestBody("application/json".toMediaType()))
                    .build()
                client.newCall(req).execute().use { resp ->
                    val raw = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        AppLogger.w(TAG, "Gemini HTTP ${resp.code}")
                        return@use Result.Fail(
                            when (resp.code) {
                                400, 403 -> "The AI service refused the request (${resp.code}). It may be blocked in your region. Try again with another VPN connected."
                                429 -> "Too many questions right now. Try again in a minute."
                                else -> "The AI service had a problem (${resp.code}). Try again later."
                            }
                        )
                    }
                    val text = parseText(raw)
                    if (text.isBlank()) Result.Fail("The AI returned an empty answer. Try rephrasing.")
                    else Result.Ok(text.trim())
                }
            } catch (e: Exception) {
                AppLogger.w(TAG, "Gemini request failed: ${e.javaClass.simpleName}")
                Result.Fail("Could not reach the AI service. Check your internet connection. It may be blocked without another VPN.")
            }
        }
    }

    private fun parseText(raw: String): String = try {
        val root: JsonObject = json.parseToJsonElement(raw).jsonObject
        val parts: JsonArray = root["candidates"]?.jsonArray?.firstOrNull()
            ?.jsonObject?.get("content")?.jsonObject?.get("parts")?.jsonArray ?: JsonArray(emptyList())
        parts.mapNotNull { (it.jsonObject["text"] as? JsonPrimitive)?.contentOrNull }.joinToString("")
    } catch (e: Exception) {
        ""
    }
}

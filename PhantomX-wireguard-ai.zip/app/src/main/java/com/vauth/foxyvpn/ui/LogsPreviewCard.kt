package com.vauth.foxyvpn.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vauth.foxyvpn.data.AppLogger
import com.vauth.foxyvpn.data.LogLevel
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * A live "Recent logs" section for the home screen: the latest few entries, a one-tap copy of the
 * whole log (handy for sharing when something misbehaves) and a shortcut to the full log screen.
 */
@Composable
fun LogsPreviewCard(
    onOpenAll: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val scheme = MaterialTheme.colorScheme
    val context = LocalContext.current
    val entries by AppLogger.entries.collectAsState()
    val timeFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }
    val recent = remember(entries) { entries.takeLast(6).asReversed() }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(scheme.surfaceContainer)
            .padding(start = 18.dp, top = 10.dp, end = 10.dp, bottom = 14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Recent logs",
                style = MaterialTheme.typography.labelMedium,
                color = scheme.onSurfaceVariant,
                modifier = Modifier.weight(1f),
            )
            TextButton(
                onClick = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                    clipboard?.setPrimaryClip(ClipData.newPlainText("Phantom X logs", AppLogger.exportAsText()))
                    Toast.makeText(context, "Logs copied", Toast.LENGTH_SHORT).show()
                },
            ) { Text("Copy") }
            TextButton(onClick = onOpenAll) { Text("Open all") }
        }

        if (recent.isEmpty()) {
            Text(
                "No log entries yet. They appear here as soon as you connect.",
                style = MaterialTheme.typography.bodySmall,
                color = scheme.onSurfaceVariant,
                modifier = Modifier.padding(end = 8.dp),
            )
        } else {
            Column(
                modifier = Modifier.padding(end = 8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                for (entry in recent) {
                    val color = when (entry.level) {
                        LogLevel.ERROR -> scheme.error
                        LogLevel.WARN -> scheme.tertiary
                        LogLevel.INFO -> scheme.onSurfaceVariant
                    }
                    Row(verticalAlignment = Alignment.Top) {
                        Text(
                            timeFormat.format(entry.timestampMillis),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                            ),
                            color = scheme.outline,
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            entry.message,
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                            color = color,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(2.dp))
    }
}

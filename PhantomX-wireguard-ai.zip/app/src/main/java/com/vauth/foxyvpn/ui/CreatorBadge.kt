package com.vauth.foxyvpn.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val BadgeBlue = Color(0xFF3D7BFF)
private val BadgeViolet = Color(0xFF9B5CFF)
private val BadgeCyan = Color(0xFF22D3EE)
private val BadgePink = Color(0xFFFF6BD6)
private val BadgeNavyStart = Color(0xFF0A0E2A)
private val BadgeNavyEnd = Color(0xFF17134D)
private val BadgeLatin = Color(0xFFD5DAF5)

/**
 * Animated creator badge: a dark glass pill with a glowing flowing border, a crowned "AM"
 * monogram inside a rotating gradient ring, the Persian name in a flowing gradient and the
 * Latin spelling between two thin lines.
 */
@Composable
fun CreatorBadge(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "creator-badge")
    val shift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3600, easing = LinearEasing), RepeatMode.Restart),
        label = "creator-shift",
    )
    val spin by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(4200, easing = LinearEasing), RepeatMode.Restart),
        label = "creator-spin",
    )
    val pulse by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1700, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "creator-pulse",
    )
    val bob by transition.animateFloat(
        initialValue = -2f,
        targetValue = 2f,
        animationSpec = infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "creator-bob",
    )

    val pillShape = RoundedCornerShape(50)

    val borderPeriod = 700f
    val borderBrush = Brush.linearGradient(
        colors = listOf(BadgeBlue, BadgeViolet, BadgeCyan, BadgeBlue),
        start = Offset(shift * borderPeriod, 0f),
        end = Offset(shift * borderPeriod + borderPeriod, 0f),
        tileMode = TileMode.Repeated,
    )

    val namePeriod = 420f
    val nameBrush = Brush.linearGradient(
        colors = listOf(BadgeCyan, BadgeViolet, BadgePink, BadgeCyan),
        start = Offset(shift * namePeriod, 0f),
        end = Offset(shift * namePeriod + namePeriod, 0f),
        tileMode = TileMode.Repeated,
    )

    Box(modifier = modifier.padding(top = 6.dp)) {
        Row(
            modifier = Modifier
                .drawBehind {
                    val g = 2.dp.toPx()
                    drawRoundRect(
                        color = BadgeViolet.copy(alpha = 0.12f + 0.20f * pulse),
                        topLeft = Offset(-g, -g),
                        size = Size(size.width + 2f * g, size.height + 2f * g),
                        cornerRadius = CornerRadius(size.height / 2f + g),
                        style = Stroke(width = 2f * g),
                    )
                }
                .background(Brush.horizontalGradient(listOf(BadgeNavyStart, BadgeNavyEnd)), pillShape)
                .border(1.dp, borderBrush, pillShape)
                .padding(horizontal = 8.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Box(
                modifier = Modifier.size(28.dp),
                contentAlignment = Alignment.Center,
            ) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .drawBehind {
                            val strokeWidth = 1.2.dp.toPx()
                            rotate(degrees = spin, pivot = center) {
                                drawCircle(
                                    brush = Brush.sweepGradient(
                                        colors = listOf(
                                            BadgeBlue,
                                            BadgeViolet,
                                            BadgeCyan,
                                            Color.Transparent,
                                            BadgeBlue,
                                        ),
                                        center = center,
                                    ),
                                    radius = size.minDimension / 2f - strokeWidth / 2f,
                                    style = Stroke(width = strokeWidth),
                                )
                            }
                        },
                )
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Color(0xFF4F7CFF), Color(0xFF7A3BFF)))),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        "AM",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 8.sp,
                            letterSpacing = 0.2.sp,
                        ),
                        color = Color.White,
                    )
                }
                Canvas(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .offset(y = (-7f + bob * 0.4f).dp)
                        .width(13.dp)
                        .height(8.dp),
                ) {
                    val w = size.width
                    val h = size.height
                    val crown = Path().apply {
                        moveTo(0f, h * 0.35f)
                        lineTo(w * 0.25f, h * 0.62f)
                        lineTo(w * 0.5f, 0f)
                        lineTo(w * 0.75f, h * 0.62f)
                        lineTo(w, h * 0.35f)
                        lineTo(w * 0.9f, h)
                        lineTo(w * 0.1f, h)
                        close()
                    }
                    drawPath(
                        path = crown,
                        brush = Brush.verticalGradient(listOf(Color(0xFFE2C8FF), Color(0xFF8A4DFF))),
                    )
                    val jewel = Color.White.copy(alpha = 0.55f + 0.45f * pulse)
                    drawCircle(jewel, radius = h * 0.10f, center = Offset(0f + h * 0.10f, h * 0.35f))
                    drawCircle(jewel, radius = h * 0.10f, center = Offset(w * 0.5f, h * 0.10f))
                    drawCircle(jewel, radius = h * 0.10f, center = Offset(w - h * 0.10f, h * 0.35f))
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "علیرضا مقیاسی",
                    style = MaterialTheme.typography.titleLarge.copy(
                        brush = nameBrush,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 11.sp,
                    ),
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .width(6.dp)
                            .height(1.dp)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color.Transparent, BadgeLatin.copy(alpha = 0.7f)),
                                ),
                            ),
                    )
                    Text(
                        "ALIREZA MOGHYASI",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 6.sp,
                            letterSpacing = 0.8.sp,
                        ),
                        color = BadgeLatin,
                    )
                    Box(
                        modifier = Modifier
                            .width(6.dp)
                            .height(1.dp)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(BadgeLatin.copy(alpha = 0.7f), Color.Transparent),
                                ),
                            ),
                    )
                }
            }
        }
    }
}

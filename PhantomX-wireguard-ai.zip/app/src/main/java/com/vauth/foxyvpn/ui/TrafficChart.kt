package com.vauth.foxyvpn.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.vauth.foxyvpn.data.formatBytesPerSecond
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

private const val WINDOW = 60              // samples kept (one per second)
private const val MIN_SCALE = 8 * 1024f    // idle traffic stays a flat line instead of zooming into noise

private val DownColor = Color(0xFF34C759)  // green: download
private val UpColor = Color(0xFF5AC8FA)    // cyan: upload

private class TrafficSeries(val down: List<Float>, val up: List<Float>)

/**
 * Live download (green) / upload (cyan) graph for ANY tunnel: the main Phantom X VPN, WARP,
 * WireGuard or the share-link protocols.
 *
 * [sample] returns the current (download, upload) speed in bytes per second. It is called once a
 * second off the main thread and must never throw (a failure is drawn as zero). Changing [resetKey]
 * starts a fresh graph, e.g. when the active tunnel changes.
 */
@Composable
fun TrafficChartCard(
    sample: () -> Pair<Long, Long>,
    modifier: Modifier = Modifier,
    resetKey: Any? = null,
) {
    key(resetKey) { TrafficChartBody(sample, modifier) }
}

@Composable
private fun TrafficChartBody(sample: () -> Pair<Long, Long>, modifier: Modifier) {
    val scheme = MaterialTheme.colorScheme
    val latestSample by rememberUpdatedState(sample)
    var series by remember { mutableStateOf(TrafficSeries(List(WINDOW) { 0f }, List(WINDOW) { 0f })) }

    LaunchedEffect(Unit) {
        while (isActive) {
            val (rx, tx) = withContext(Dispatchers.IO) {
                runCatching { latestSample() }.getOrDefault(0L to 0L)
            }
            val cur = series
            series = TrafficSeries(
                (cur.down + rx.coerceAtLeast(0L).toFloat()).takeLast(WINDOW),
                (cur.up + tx.coerceAtLeast(0L).toFloat()).takeLast(WINDOW),
            )
            delay(1000)
        }
    }

    val gridColor = scheme.onSurface.copy(alpha = 0.08f)
    val peak = maxOf(MIN_SCALE, series.down.max(), series.up.max()) * 1.1f

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(scheme.surfaceContainer)
            .padding(18.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Live traffic",
                style = MaterialTheme.typography.labelMedium,
                color = scheme.onSurfaceVariant,
                modifier = Modifier.weight(1f),
            )
            LegendDot(DownColor, "Download")
            Spacer(Modifier.width(12.dp))
            LegendDot(UpColor, "Upload")
        }
        Spacer(Modifier.height(10.dp))
        Canvas(modifier = Modifier.fillMaxWidth().height(100.dp)) {
            val w = size.width
            val h = size.height
            val pad = 4.dp.toPx()
            val top = pad
            val bottom = h - pad

            for (i in 1..2) {
                val y = top + (bottom - top) * i / 3f
                drawLine(gridColor, Offset(0f, y), Offset(w, y), strokeWidth = 1.dp.toPx())
            }

            val step = w / (WINDOW - 1)
            fun points(data: List<Float>): List<Offset> =
                data.mapIndexed { i, v -> Offset(i * step, bottom - (v / peak) * (bottom - top)) }

            fun smooth(pts: List<Offset>): Path {
                val path = Path()
                if (pts.isEmpty()) return path
                path.moveTo(pts[0].x, pts[0].y)
                for (i in 1 until pts.size) {
                    val a = pts[i - 1]
                    val b = pts[i]
                    val mx = (a.x + b.x) / 2f
                    path.cubicTo(mx, a.y, mx, b.y, b.x, b.y)
                }
                return path
            }

            val downPts = points(series.down)
            val upPts = points(series.up)

            val fill = smooth(downPts).apply {
                lineTo(w, bottom)
                lineTo(0f, bottom)
                close()
            }
            drawPath(
                fill,
                Brush.verticalGradient(listOf(DownColor.copy(alpha = 0.28f), Color.Transparent), startY = top, endY = bottom),
            )

            val stroke = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
            drawPath(smooth(upPts), UpColor, style = stroke)
            drawPath(smooth(downPts), DownColor, style = stroke)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "Last 60 s \u2022 scale ${formatBytesPerSecond(peak.toLong())}",
            style = MaterialTheme.typography.labelSmall,
            color = scheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

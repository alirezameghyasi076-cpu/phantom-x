package com.vauth.foxyvpn.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import com.vauth.foxyvpn.R

@Composable
fun PhantomLogo(size: Dp, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(R.drawable.phantom_logo),
        contentDescription = "Phantom X",
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.24f)),
    )
}

package com.vauth.foxyvpn.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vauth.foxyvpn.BuildConfig
import com.vauth.foxyvpn.data.FxaAuthRepository
import com.vauth.foxyvpn.ui.PhantomLogo
import com.vauth.foxyvpn.ui.CreatorBadge
import com.vauth.foxyvpn.ui.theme.PhantomCyan
import com.vauth.foxyvpn.ui.theme.PhantomViolet
import kotlinx.coroutines.launch

private const val FIREFOX_SIGNUP_URL = "https://accounts.firefox.com/signup"
private val StripWhitespace = Regex("[\\p{Z}\\u200B-\\u200D\\uFEFF\\u00A0\\s]+")
private val StripZeroWidth = Regex("[\\u200B-\\u200D\\uFEFF]")

@Composable
fun LoginScreen(
    authRepository: FxaAuthRepository,
    onSignedIn: () -> Unit,
) {
    var email by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var code by rememberSaveable { mutableStateOf("") }
    var showPassword by rememberSaveable { mutableStateOf(false) }
    var ownAccount by rememberSaveable { mutableStateOf(false) }
    var awaitingTwoFactor by rememberSaveable { mutableStateOf(authRepository.pendingSessionToken != null) }
    var isLoading by remember { mutableStateOf(false) }
    var loadingDefault by remember { mutableStateOf(false) }
    var errorMessage by rememberSaveable { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current
    val context = LocalContext.current
    val scheme = MaterialTheme.colorScheme
    val hasDefaultAccount = BuildConfig.DEFAULT_EMAIL.isNotBlank() && BuildConfig.DEFAULT_PASSWORD.isNotBlank()

    BackHandler(enabled = awaitingTwoFactor) {
        authRepository.clearPendingSession()
        awaitingTwoFactor = false
        errorMessage = null
        code = ""
    }
    BackHandler(enabled = ownAccount && !awaitingTwoFactor) {
        ownAccount = false
        errorMessage = null
    }

    fun signIn(rawEmail: String, rawPassword: String, viaDefault: Boolean) {
        val cleanEmail = FxaAuthRepository.normalizeEmail(rawEmail)
        if (cleanEmail.isBlank() || rawPassword.isBlank() || isLoading) return
        errorMessage = null
        isLoading = true
        loadingDefault = viaDefault
        scope.launch {
            val result = authRepository.startLogin(cleanEmail, rawPassword)
            isLoading = false
            result.onSuccess { needsVerification ->
                if (needsVerification) awaitingTwoFactor = true else onSignedIn()
            }.onFailure { errorMessage = it.message ?: "ورود ناموفق بود" }
        }
    }

    fun submitCode() {
        val cleanCode = FxaAuthRepository.sanitizeCode(code)
        if (cleanCode.isBlank() || isLoading) return
        errorMessage = null
        isLoading = true
        loadingDefault = false
        scope.launch {
            val result = authRepository.submitTwoFactorCode(cleanCode)
            isLoading = false
            result.onSuccess { onSignedIn() }
                .onFailure {
                    errorMessage = it.message ?: "تأیید ناموفق بود"
                    if (authRepository.pendingSessionToken == null) awaitingTwoFactor = false
                }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(scheme.background, scheme.surfaceContainerLowest)))
                .imePadding(),
        ) {
            Column(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .widthIn(max = 520.dp)
                    .fillMaxSize()
                    .systemBarsPadding()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                when {
                    awaitingTwoFactor -> {
                        Spacer(Modifier.height(24.dp))
                        LogoWithGlow(110.dp)
                        Spacer(Modifier.height(20.dp))
                        Text(
                            "کد تأیید رو وارد کن",
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "فایرفاکس یه کد به ایمیلت فرستاده. همون کد رو اینجا بنویس تا ورودت کامل بشه.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = scheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                        )
                        Spacer(Modifier.height(24.dp))
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            OutlinedTextField(
                                value = code,
                                onValueChange = { code = it.replace(StripWhitespace, "") },
                                label = { Text("Confirmation code") },
                                singleLine = true,
                                shape = RoundedCornerShape(16.dp),
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.NumberPassword,
                                    imeAction = ImeAction.Done,
                                ),
                                keyboardActions = KeyboardActions(onDone = {
                                    focusManager.clearFocus()
                                    submitCode()
                                }),
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }
                        Spacer(Modifier.height(20.dp))
                        PrimaryAction(
                            text = "تأیید و ادامه",
                            loading = isLoading,
                            enabled = !isLoading && code.isNotBlank(),
                        ) {
                            focusManager.clearFocus()
                            submitCode()
                        }
                    }

                    ownAccount -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            IconButton(onClick = {
                                ownAccount = false
                                errorMessage = null
                            }) {
                                Icon(Icons.Filled.ArrowForward, contentDescription = "بازگشت", tint = scheme.onSurfaceVariant)
                            }
                            Text(
                                "ورود با اکانت فایرفاکس",
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            )
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "برای استفاده از ۵۰ گیگ ترافیک رایگان ماهانه، فقط یه اکانت فایرفاکس لازم داری. سه قدم ساده:",
                            style = MaterialTheme.typography.bodyLarge,
                            color = scheme.onSurfaceVariant,
                        )
                        Spacer(Modifier.height(16.dp))

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(24.dp))
                                .background(scheme.surfaceContainer)
                                .padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(18.dp),
                        ) {
                            GuideStep(
                                number = "۱",
                                title = "اکانت فایرفاکس بساز",
                                body = "اگه اکانت نداری، دکمه‌ی زیر رو بزن. توی صفحه‌ی فایرفاکس یه ایمیل (مثلاً جیمیل) و یه رمز دلخواه وارد کن.",
                            ) {
                                FilledTonalButton(onClick = {
                                    context.startActivity(
                                        Intent(Intent.ACTION_VIEW, Uri.parse(FIREFOX_SIGNUP_URL))
                                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                                    )
                                }) {
                                    Icon(Icons.Filled.Public, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text("ثبت‌نام در فایرفاکس")
                                }
                            }
                            GuideStep(
                                number = "۲",
                                title = "ایمیلت رو تأیید کن",
                                body = "فایرفاکس یه کد برای ایمیلت می‌فرسته. کد رو همون‌جا وارد کن تا اکانت فعال بشه.",
                            )
                            GuideStep(
                                number = "۳",
                                title = "برگرد و وارد شو",
                                body = "همون ایمیل و رمز رو پایین بنویس. اتصال خودش آماده می‌شه.",
                            )
                        }

                        Spacer(Modifier.height(20.dp))
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Column(Modifier.fillMaxWidth()) {
                                OutlinedTextField(
                                    value = email,
                                    onValueChange = { email = it.replace(StripWhitespace, "").lowercase() },
                                    label = { Text("Email (Gmail)") },
                                    leadingIcon = { Icon(Icons.Filled.Email, contentDescription = null) },
                                    singleLine = true,
                                    shape = RoundedCornerShape(16.dp),
                                    keyboardOptions = KeyboardOptions(
                                        keyboardType = KeyboardType.Email,
                                        imeAction = ImeAction.Next,
                                        autoCorrectEnabled = false,
                                    ),
                                    keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
                                    modifier = Modifier.fillMaxWidth(),
                                )
                                Spacer(Modifier.height(12.dp))
                                OutlinedTextField(
                                    value = password,
                                    onValueChange = { password = it.replace(StripZeroWidth, "") },
                                    label = { Text("Password") },
                                    leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = null) },
                                    trailingIcon = {
                                        IconButton(onClick = { showPassword = !showPassword }) {
                                            Icon(
                                                if (showPassword) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                                contentDescription = if (showPassword) "پنهان کردن رمز" else "نمایش رمز",
                                            )
                                        }
                                    },
                                    singleLine = true,
                                    shape = RoundedCornerShape(16.dp),
                                    visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                                    keyboardOptions = KeyboardOptions(
                                        keyboardType = KeyboardType.Password,
                                        imeAction = ImeAction.Done,
                                    ),
                                    keyboardActions = KeyboardActions(onDone = {
                                        focusManager.clearFocus()
                                        signIn(email, password, false)
                                    }),
                                    modifier = Modifier.fillMaxWidth(),
                                )
                            }
                        }
                        Spacer(Modifier.height(20.dp))
                        PrimaryAction(
                            text = "ورود",
                            loading = isLoading,
                            enabled = !isLoading && email.isNotBlank() && password.isNotBlank(),
                        ) {
                            focusManager.clearFocus()
                            signIn(email, password, false)
                        }
                    }

                    else -> {
                        Spacer(Modifier.height(32.dp))
                        LogoWithGlow(150.dp)
                        Spacer(Modifier.height(24.dp))
                        Text(
                            "به Phantom X خوش اومدی",
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
                            textAlign = TextAlign.Center,
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "برای شروع یکی از این دو راه رو انتخاب کن.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = scheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                        )
                        Spacer(Modifier.height(28.dp))
                        if (hasDefaultAccount) {
                            ChoiceCard(
                                title = "ادامه با اکانت پیش‌فرض",
                                subtitle = "بدون ثبت‌نام، با یک ضربه وصل شو.",
                                icon = Icons.Filled.Bolt,
                                highlighted = true,
                                loading = isLoading && loadingDefault,
                                enabled = !isLoading,
                                badge = "پیشنهادی",
                            ) {
                                signIn(BuildConfig.DEFAULT_EMAIL, BuildConfig.DEFAULT_PASSWORD, true)
                            }
                            Spacer(Modifier.height(14.dp))
                        }
                        ChoiceCard(
                            title = "اکانت خودم رو دارم",
                            subtitle = "با ایمیل و رمز اکانت فایرفاکس خودت وارد شو.",
                            icon = Icons.Filled.Person,
                            highlighted = false,
                            loading = false,
                            enabled = !isLoading,
                        ) {
                            errorMessage = null
                            ownAccount = true
                        }
                        Spacer(Modifier.height(16.dp))
                        Text(
                            "هر دو راه از ۵۰ گیگ ترافیک رایگان ماهانه‌ی فایرفاکس استفاده می‌کنن و اشتراک لازم نیست.",
                            style = MaterialTheme.typography.bodySmall,
                            color = scheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                        )
                    }
                }

                errorMessage?.let {
                    Spacer(Modifier.height(14.dp))
                    Text(
                        text = it,
                        color = scheme.error,
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                    )
                }

                Spacer(Modifier.height(28.dp))
                CreatorBadge()
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun LogoWithGlow(size: androidx.compose.ui.unit.Dp) {
    Box(
        modifier = Modifier
            .size(size * 1.5f)
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(PhantomViolet.copy(alpha = 0.45f), Color.Transparent),
                        center = center,
                        radius = this.size.minDimension / 2f,
                    ),
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        PhantomLogo(size = size)
    }
}

@Composable
private fun PrimaryAction(text: String, loading: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth().height(56.dp),
    ) {
        if (loading) {
            CircularProgressIndicator(
                modifier = Modifier.size(22.dp),
                strokeWidth = 2.dp,
                color = MaterialTheme.colorScheme.onPrimary,
            )
        } else {
            Text(text, style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable
private fun GuideStep(
    number: String,
    title: String,
    body: String,
    action: (@Composable () -> Unit)? = null,
) {
    Row(verticalAlignment = Alignment.Top) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                number,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            Spacer(Modifier.height(4.dp))
            Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (action != null) {
                Spacer(Modifier.height(12.dp))
                action()
            }
        }
    }
}

@Composable
private fun ChoiceCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    highlighted: Boolean,
    loading: Boolean,
    enabled: Boolean,
    badge: String? = null,
    onClick: () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(28.dp)
    val accent = if (highlighted) PhantomCyan else scheme.primary
    val fill = if (highlighted) {
        Brush.linearGradient(listOf(scheme.primaryContainer, scheme.surfaceContainerHigh))
    } else {
        Brush.linearGradient(listOf(scheme.surfaceContainerHigh, scheme.surfaceContainerHigh))
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(fill)
            .border(if (highlighted) 1.5.dp else 1.dp, if (highlighted) PhantomCyan else scheme.outlineVariant, shape)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(20.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(accent.copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = accent)
        }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                if (badge != null) {
                    Spacer(Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(PhantomCyan.copy(alpha = 0.18f))
                            .padding(horizontal = 10.dp, vertical = 3.dp),
                    ) {
                        Text(
                            badge,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = PhantomCyan,
                        )
                    }
                }
            }
            Spacer(Modifier.height(2.dp))
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = scheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(8.dp))
        if (loading) {
            CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
        } else {
            Icon(Icons.Filled.ChevronLeft, contentDescription = null, tint = scheme.onSurfaceVariant)
        }
    }
}

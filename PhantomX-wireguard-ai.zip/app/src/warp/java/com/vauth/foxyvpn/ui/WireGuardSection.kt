package com.vauth.foxyvpn.ui

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.net.VpnService
import android.os.PersistableBundle
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vauth.foxyvpn.data.formatBytes
import com.vauth.foxyvpn.data.formatBytesPerSecond
import com.vauth.foxyvpn.wireguard.DiagItem
import com.vauth.foxyvpn.wireguard.DiagLevel
import com.vauth.foxyvpn.wireguard.WgConfigText
import com.vauth.foxyvpn.wireguard.WgDiagnostics
import com.vauth.foxyvpn.wireguard.WgKeys
import com.vauth.foxyvpn.wireguard.WgManager
import com.vauth.foxyvpn.wireguard.WgProfile
import com.vauth.foxyvpn.wireguard.WgProfileStore
import com.vauth.foxyvpn.wireguard.WgQr
import com.vauth.foxyvpn.wireguard.WgState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private data class EditorRequest(
    val profileId: String?,
    val name: String,
    val config: String,
    val fallbacks: String = "",
    val autoKeepalive: Boolean = true,
    val bypassIranian: Boolean = false,
)

private const val TEMPLATE_PEER = """
[Peer]
PublicKey = SERVER_PUBLIC_KEY
AllowedIPs = 0.0.0.0/0, ::/0
Endpoint = server.example.com:51820
PersistentKeepalive = 25
"""

/**
 * Full WireGuard client: profiles (import from file, clipboard, link or QR picture), key management,
 * connect/disconnect, live status and automatic diagnostics.
 * Shown inside the "Extra tunnels" card of the WARP build.
 */
@Composable
fun WireGuardSection() {
    val scheme = MaterialTheme.colorScheme
    val context = LocalContext.current
    val ui by WgManager.ui.collectAsState()
    val profiles by WgProfileStore.profiles.collectAsState()
    val activeId by WgProfileStore.activeId.collectAsState()
    val storeError by WgProfileStore.error.collectAsState()

    LaunchedEffect(Unit) { withContext(Dispatchers.IO) { WgProfileStore.init(context) } }

    var editor by remember { mutableStateOf<EditorRequest?>(null) }
    var keysFor by remember { mutableStateOf<String?>(null) }
    var deleteFor by remember { mutableStateOf<String?>(null) }
    var addMenu by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf<String?>(null) }
    var pendingConnect by remember { mutableStateOf<String?>(null) }
    var exportId by remember { mutableStateOf<String?>(null) }
    var showAllDiag by remember { mutableStateOf(false) }

    fun openImport(raw: String, suggestedName: String) {
        val text = raw.trim()
        val link = WgConfigText.fromLink(text)
        val config = link?.first ?: text
        val name = link?.second ?: suggestedName
        if (!config.contains("[Interface]", ignoreCase = true)) {
            notice = "That is not a WireGuard config or wireguard:// link."
            return
        }
        notice = null
        editor = EditorRequest(null, name, config)
    }

    val vpnLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val id = pendingConnect
        pendingConnect = null
        if (result.resultCode == Activity.RESULT_OK && id != null) WgManager.connect(context, id)
        else notice = "VPN permission was not granted."
    }

    fun connect(id: String) {
        notice = null
        val intent = VpnService.prepare(context)
        if (intent == null) {
            WgManager.connect(context, id)
        } else {
            pendingConnect = id
            vpnLauncher.launch(intent)
        }
    }

    val fileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            val bytes = runCatching { context.contentResolver.openInputStream(uri)?.use { it.readBytes() } }.getOrNull()
            if (bytes == null || bytes.size > 256 * 1024) notice = "The file could not be read."
            else openImport(String(bytes, Charsets.UTF_8), displayName(context, uri).removeSuffix(".conf"))
        }
    }

    val qrLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            val text = WgQr.decode(context, uri)
            if (text == null) notice = "No QR code found in that picture."
            else openImport(text, "WireGuard")
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri: Uri? ->
        val profile = WgProfileStore.get(exportId)
        exportId = null
        if (uri != null && profile != null) {
            val ok = runCatching {
                context.contentResolver.openOutputStream(uri)?.use { it.write(profile.config.toByteArray()) }
            }.isSuccess
            notice = if (ok) "Saved. The file contains your private key, keep it safe." else "Could not save the file."
        }
    }

    val state = ui.state
    val busy = state == WgState.CONNECTING || state == WgState.RECONNECTING
    val connected = state == WgState.CONNECTED
    val active = WgProfileStore.get(activeId)

    Spacer(Modifier.height(16.dp))
    HorizontalDivider(color = scheme.outlineVariant)
    Spacer(Modifier.height(12.dp))

    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(modifier = Modifier.weight(1f)) {
            Text("WireGuard", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold))
            Text(
                ui.message,
                style = MaterialTheme.typography.bodySmall,
                color = when (state) {
                    WgState.CONNECTED -> scheme.primary
                    WgState.FAILED -> scheme.error
                    else -> scheme.onSurfaceVariant
                },
            )
        }
        if (busy) CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
    }

    storeError?.let {
        Spacer(Modifier.height(6.dp))
        Text(it, style = MaterialTheme.typography.bodySmall, color = scheme.error)
    }
    notice?.let {
        Spacer(Modifier.height(6.dp))
        Text(it, style = MaterialTheme.typography.bodySmall, color = scheme.tertiary)
    }

    Spacer(Modifier.height(8.dp))
    if (profiles.isEmpty()) {
        Text(
            "No profile yet. Import a .conf file, a QR picture, paste a config or a wireguard:// link, or create a new one.",
            style = MaterialTheme.typography.bodySmall,
            color = scheme.onSurfaceVariant,
        )
    }
    for (p in profiles) {
        ProfileRow(
            profile = p,
            selected = p.id == activeId,
            enabled = !busy && !connected,
            onSelect = { WgProfileStore.select(p.id) },
            onEdit = {
                editor = EditorRequest(p.id, p.name, p.config, p.fallbackEndpoints.joinToString("\n"), p.autoKeepalive, p.bypassIranianApps)
            },
            onKeys = { keysFor = p.id },
            onExport = {
                exportId = p.id
                exportLauncher.launch("${p.name.ifBlank { "wireguard" }}.conf")
            },
            onDelete = { deleteFor = p.id },
        )
    }

    Spacer(Modifier.height(4.dp))
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Column {
            TextButton(onClick = { addMenu = true }) { Text("Add profile") }
            DropdownMenu(expanded = addMenu, onDismissRequest = { addMenu = false }) {
                DropdownMenuItem(text = { Text("Paste from clipboard") }, onClick = {
                    addMenu = false
                    val clip = readClip(context)
                    if (clip.isBlank()) notice = "The clipboard is empty." else openImport(clip, "WireGuard")
                })
                DropdownMenuItem(text = { Text("Import .conf file") }, onClick = {
                    addMenu = false
                    fileLauncher.launch(arrayOf("*/*"))
                })
                DropdownMenuItem(text = { Text("Import QR picture") }, onClick = {
                    addMenu = false
                    qrLauncher.launch("image/*")
                })
                DropdownMenuItem(text = { Text("Create new (generate keys)") }, onClick = {
                    addMenu = false
                    val keys = WgKeys.generate()
                    val config = "[Interface]\nPrivateKey = ${keys.privateKey}\nAddress = 10.0.0.2/32\nDNS = 1.1.1.1\n$TEMPLATE_PEER"
                    editor = EditorRequest(null, "My WireGuard", config)
                })
            }
        }
        Spacer(Modifier.weight(1f))
        if (busy) {
            TextButton(onClick = { WgManager.disconnect(context) }) { Text("Cancel") }
        } else {
            FilledTonalButton(
                onClick = { if (connected) WgManager.disconnect(context) else active?.let { connect(it.id) } },
                enabled = connected || active != null,
            ) { Text(if (connected) "Disconnect" else "Connect") }
        }
    }

    if (connected || state == WgState.RECONNECTING) {
        Spacer(Modifier.height(8.dp))
        StatusGrid(ui.endpoint, ui.stats.connectedSince, ui.stats.handshakeAgeSec, ui.stats.rx, ui.stats.tx, ui.stats.rxRate, ui.stats.txRate)
    }

    val showDiag = ui.diagnostics.isNotEmpty() || connected || state == WgState.FAILED
    if (showDiag || active != null) {
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Diagnostics", style = MaterialTheme.typography.labelMedium, color = scheme.onSurfaceVariant, modifier = Modifier.weight(1f))
            if (ui.diagnosing) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
            } else {
                TextButton(onClick = { WgManager.diagnose(context, activeId) }, enabled = !busy) { Text("Run") }
            }
            if (ui.diagnostics.isNotEmpty()) {
                TextButton(onClick = {
                    copyText(context, "WireGuard report", WgDiagnostics.report(ui.profileName, ui.state.name, ui.message, ui.diagnostics), false)
                    notice = "Report copied (it contains no keys)."
                }) { Text("Copy report") }
            }
        }
        val sorted = ui.diagnostics.sortedBy { it.level.ordinal.let { o -> 3 - o } }
        val shown = if (showAllDiag || sorted.size <= 5) sorted else sorted.take(5)
        for (item in shown) DiagRow(item)
        if (sorted.size > 5) {
            TextButton(onClick = { showAllDiag = !showAllDiag }) { Text(if (showAllDiag) "Show less" else "Show all (${sorted.size})") }
        }
    }

    // ---------------------------------------------------------------- dialogs

    editor?.let { req ->
        EditorDialog(
            request = req,
            onDismiss = { editor = null },
            onSave = { saved ->
                val existing = WgProfileStore.get(saved.profileId)
                val base = existing ?: WgProfileStore.newProfile(saved.name, saved.config)
                val stored = WgProfileStore.upsert(
                    base.copy(
                        name = saved.name.ifBlank { "WireGuard" },
                        config = saved.config,
                        fallbackEndpoints = saved.fallbacks.lines().map { it.trim() }.filter { it.isNotEmpty() },
                        autoKeepalive = saved.autoKeepalive,
                        bypassIranianApps = saved.bypassIranian,
                    ),
                )
                WgProfileStore.select(stored.id)
                editor = null
                notice = if (existing != null && connected && ui.profileId == existing.id) "Saved. Reconnect to apply the changes." else null
            },
        )
    }

    keysFor?.let { id ->
        val profile = profiles.firstOrNull { it.id == id }
        if (profile == null) {
            keysFor = null
        } else {
            KeysDialog(profile = profile, onClose = { keysFor = null }, connectedHere = connected && ui.profileId == id)
        }
    }

    deleteFor?.let { id ->
        val profile = profiles.firstOrNull { it.id == id }
        if (profile == null) {
            deleteFor = null
        } else {
            AlertDialog(
                onDismissRequest = { deleteFor = null },
                title = { Text("Delete \u201C${profile.name}\u201D?") },
                text = { Text("The profile and its keys are removed from this phone. Export it first if you need it again.") },
                confirmButton = {
                    TextButton(onClick = {
                        if (ui.profileId == id && (connected || busy)) WgManager.disconnect(context)
                        WgProfileStore.delete(id)
                        deleteFor = null
                    }) { Text("Delete") }
                },
                dismissButton = { TextButton(onClick = { deleteFor = null }) { Text("Cancel") } },
            )
        }
    }
}

@Composable
private fun ProfileRow(
    profile: WgProfile,
    selected: Boolean,
    enabled: Boolean,
    onSelect: () -> Unit,
    onEdit: () -> Unit,
    onKeys: () -> Unit,
    onExport: () -> Unit,
    onDelete: () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    val endpoint = remember(profile.config) { WgConfigText.parse(profile.config).peers.firstOrNull()?.get("Endpoint").orEmpty() }
    var menu by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier.fillMaxWidth().clickable(enabled = enabled, onClick = onSelect),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onSelect, enabled = enabled)
        Column(modifier = Modifier.weight(1f)) {
            Text(profile.name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium))
            if (endpoint.isNotEmpty()) Text(endpoint, style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant)
        }
        Column {
            IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, contentDescription = "Profile options") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Edit") }, onClick = { menu = false; onEdit() })
                DropdownMenuItem(text = { Text("Keys") }, onClick = { menu = false; onKeys() })
                DropdownMenuItem(text = { Text("Export .conf") }, onClick = { menu = false; onExport() })
                DropdownMenuItem(text = { Text("Delete") }, onClick = { menu = false; onDelete() })
            }
        }
    }
}

@Composable
private fun StatusGrid(endpoint: String?, since: Long, handshakeAge: Long?, rx: Long, tx: Long, rxRate: Long, txRate: Long) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        if (endpoint != null) StatLine("Endpoint", endpoint)
        if (since > 0) StatLine("Connected for", duration(System.currentTimeMillis() - since))
        StatLine("Last handshake", handshakeAge?.let { ago(it) } ?: "waiting\u2026")
        StatLine("Download", "${formatBytes(rx)}  \u2022  ${formatBytesPerSecond(rxRate)}")
        StatLine("Upload", "${formatBytes(tx)}  \u2022  ${formatBytesPerSecond(txRate)}")
    }
}

@Composable
private fun StatLine(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun DiagRow(item: DiagItem) {
    val scheme = MaterialTheme.colorScheme
    val (mark, color) = when (item.level) {
        DiagLevel.OK -> "\u2713" to scheme.primary
        DiagLevel.INFO -> "i" to scheme.onSurfaceVariant
        DiagLevel.WARN -> "!" to scheme.tertiary
        DiagLevel.ERROR -> "\u2715" to scheme.error
    }
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(mark, color = color, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 1.dp))
        Column {
            Text(item.title, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold), color = color)
            if (item.detail.isNotBlank()) Text(item.detail, style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant)
            if (item.fix.isNotBlank()) Text("\u2192 ${item.fix}", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun EditorDialog(request: EditorRequest, onDismiss: () -> Unit, onSave: (EditorRequest) -> Unit) {
    val context = LocalContext.current
    val scheme = MaterialTheme.colorScheme
    var name by remember { mutableStateOf(request.name) }
    var config by remember { mutableStateOf(request.config) }
    var fallbacks by remember { mutableStateOf(request.fallbacks) }
    var keepalive by remember { mutableStateOf(request.autoKeepalive) }
    var bypass by remember { mutableStateOf(request.bypassIranian) }
    val validation = remember(config) { WgManager.validate(config) }
    val problems = validation.items.filter { it.level == DiagLevel.ERROR || it.level == DiagLevel.WARN }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (request.profileId == null) "New WireGuard profile" else "Edit profile") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, singleLine = true,
                    label = { Text("Name") }, modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = config, onValueChange = { config = it },
                    label = { Text("Config") }, modifier = Modifier.fillMaxWidth(),
                    minLines = 8, maxLines = 14,
                    textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
                )
                for (item in problems) DiagRow(item)
                validation.publicKey?.let { pub ->
                    Text("Your public key (give it to the server):", style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant)
                    Text(pub, style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace))
                    TextButton(onClick = { copyText(context, "WireGuard public key", pub, false) }) { Text("Copy public key") }
                }
                if (validation.publicKey == null) {
                    TextButton(onClick = {
                        val (newConfig, _) = WgKeys.rotatePrivateKey(config)
                        config = newConfig
                    }) { Text("Generate private key") }
                }
                OutlinedTextField(
                    value = fallbacks, onValueChange = { fallbacks = it },
                    label = { Text("Fallback endpoints (optional)") },
                    placeholder = { Text("host:443\nhost:53") },
                    modifier = Modifier.fillMaxWidth(), minLines = 2, maxLines = 4,
                )
                SwitchRow("Keepalive 25 s when missing (faster start, survives NAT)", keepalive) { keepalive = it }
                SwitchRow("Let Iranian apps skip this tunnel", bypass) { bypass = it }
            }
        },
        confirmButton = {
            TextButton(
                enabled = config.isNotBlank() && !validation.hasErrors,
                onClick = { onSave(request.copy(name = name.trim(), config = config.trim() + "\n", fallbacks = fallbacks, autoKeepalive = keepalive, bypassIranian = bypass)) },
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(label, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun KeysDialog(profile: WgProfile, onClose: () -> Unit, connectedHere: Boolean) {
    val context = LocalContext.current
    val scheme = MaterialTheme.colorScheme
    var reveal by remember { mutableStateOf(false) }
    var confirmRotate by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<String?>(null) }

    val parsed = remember(profile.config) { WgConfigText.parse(profile.config) }
    val privateKey = parsed.iface?.get("PrivateKey").orEmpty()
    val publicKey = remember(profile.config) { WgKeys.publicKeyOf(parsed) }
    val preshared = parsed.peers.firstOrNull()?.get("PresharedKey")
    val serverKey = parsed.peers.firstOrNull()?.get("PublicKey")

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Keys \u2013 ${profile.name}") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Your public key", style = MaterialTheme.typography.labelMedium, color = scheme.onSurfaceVariant)
                Text(publicKey ?: "No valid private key", style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace))
                if (publicKey != null) TextButton(onClick = { copyText(context, "WireGuard public key", publicKey, false); info = "Public key copied." }) { Text("Copy public key") }

                Text("Private key", style = MaterialTheme.typography.labelMedium, color = scheme.onSurfaceVariant)
                Text(
                    if (reveal) privateKey.ifEmpty { "\u2014" } else if (privateKey.isEmpty()) "\u2014" else "\u2022".repeat(24),
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                )
                Row {
                    TextButton(onClick = { reveal = !reveal }) { Text(if (reveal) "Hide" else "Reveal") }
                    if (privateKey.isNotEmpty()) TextButton(onClick = { copyText(context, "WireGuard private key", privateKey, true); info = "Private key copied. Clear the clipboard after use." }) { Text("Copy") }
                }

                if (serverKey != null) {
                    Text("Server public key", style = MaterialTheme.typography.labelMedium, color = scheme.onSurfaceVariant)
                    Text(serverKey, style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace))
                }

                Text("Preshared key", style = MaterialTheme.typography.labelMedium, color = scheme.onSurfaceVariant)
                Text(
                    preshared?.let { WgKeys.mask(it) } ?: "Not used",
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                )
                Row {
                    TextButton(onClick = {
                        WgProfileStore.upsert(profile.copy(config = WgKeys.setPresharedKey(profile.config, WgKeys.generatePresharedKey())))
                        info = "New preshared key set. The server needs the same value."
                    }, enabled = parsed.peers.isNotEmpty()) { Text(if (preshared == null) "Generate" else "Replace") }
                    if (preshared != null) TextButton(onClick = {
                        WgProfileStore.upsert(profile.copy(config = WgKeys.setPresharedKey(profile.config, null)))
                        info = "Preshared key removed."
                    }) { Text("Remove") }
                }

                HorizontalDivider(color = scheme.outlineVariant)
                TextButton(onClick = { confirmRotate = true }) { Text("Generate new key pair") }
                if (connectedHere) Text("Reconnect after changing keys.", style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant)
                info?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = scheme.tertiary) }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Close") } },
    )

    if (confirmRotate) {
        AlertDialog(
            onDismissRequest = { confirmRotate = false },
            title = { Text("Replace the key pair?") },
            text = { Text("The tunnel stops working until you register the NEW public key on the server. The old private key is deleted from this phone.") },
            confirmButton = {
                TextButton(onClick = {
                    val (newConfig, newPublic) = WgKeys.rotatePrivateKey(profile.config)
                    WgProfileStore.upsert(profile.copy(config = newConfig))
                    copyText(context, "WireGuard public key", newPublic, false)
                    info = "New public key copied: $newPublic"
                    confirmRotate = false
                }) { Text("Replace") }
            },
            dismissButton = { TextButton(onClick = { confirmRotate = false }) { Text("Cancel") } },
        )
    }
}

// -------------------------------------------------------------------- helpers

private fun readClip(context: Context): String {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    return cm.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString()?.trim().orEmpty()
}

/** Copies text; [sensitive] asks Android 13+ to hide the content in the clipboard preview. */
private fun copyText(context: Context, label: String, text: String, sensitive: Boolean) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText(label, text)
    if (sensitive) {
        clip.description.extras = PersistableBundle().apply { putBoolean("android.content.extra.IS_SENSITIVE", true) }
    }
    cm.setPrimaryClip(clip)
}

private fun displayName(context: Context, uri: Uri): String {
    val fallback = uri.lastPathSegment?.substringAfterLast('/') ?: "WireGuard"
    return runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull() ?: fallback
}

private fun ago(seconds: Long): String =
    if (seconds < 60) "${seconds}s ago" else "${seconds / 60}m ${seconds % 60}s ago"

private fun duration(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

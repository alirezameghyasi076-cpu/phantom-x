package com.vauth.foxyvpn.wireguard

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.vauth.foxyvpn.data.AppLogger
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID

/** Encrypted storage for WireGuard profiles (they contain private keys). */
object WgProfileStore {
    private const val TAG = "WgProfileStore"
    private const val FILE = "phantom_wg_profiles"
    private const val KEY_PROFILES = "profiles"
    private const val KEY_ACTIVE = "active"

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    private val _profiles = MutableStateFlow<List<WgProfile>>(emptyList())
    val profiles: StateFlow<List<WgProfile>> = _profiles.asStateFlow()

    private val _activeId = MutableStateFlow<String?>(null)
    val activeId: StateFlow<String?> = _activeId.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    @Volatile
    private var prefs: android.content.SharedPreferences? = null

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        try {
            val app = context.applicationContext
            val masterKey = MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            val p = EncryptedSharedPreferences.create(
                app, FILE, masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
            )
            prefs = p
            val stored = p.getString(KEY_PROFILES, null)
            _profiles.value = if (stored.isNullOrBlank()) emptyList()
            else runCatching { json.decodeFromString<List<WgProfile>>(stored) }.getOrElse {
                AppLogger.w(TAG, "could not read stored profiles", it)
                emptyList()
            }
            val active = p.getString(KEY_ACTIVE, null)
            _activeId.value = active?.takeIf { id -> _profiles.value.any { it.id == id } } ?: _profiles.value.firstOrNull()?.id
            _error.value = null
        } catch (t: Throwable) {
            AppLogger.e(TAG, "secure storage unavailable", t)
            _error.value = "Secure storage is unavailable on this device, profiles cannot be saved."
        }
    }

    fun get(id: String?): WgProfile? = id?.let { wanted -> _profiles.value.firstOrNull { it.id == wanted } }

    @Synchronized
    fun upsert(profile: WgProfile): WgProfile {
        val stamped = if (profile.createdAt == 0L) profile.copy(createdAt = System.currentTimeMillis()) else profile
        val list = _profiles.value.toMutableList()
        val index = list.indexOfFirst { it.id == stamped.id }
        if (index >= 0) list[index] = stamped else list.add(stamped)
        _profiles.value = list
        persist()
        return stamped
    }

    fun newProfile(name: String, config: String): WgProfile =
        WgProfile(id = UUID.randomUUID().toString(), name = name.ifBlank { "WireGuard" }, config = config)

    @Synchronized
    fun delete(id: String) {
        _profiles.value = _profiles.value.filterNot { it.id == id }
        if (_activeId.value == id) _activeId.value = _profiles.value.firstOrNull()?.id
        persist()
    }

    @Synchronized
    fun select(id: String) {
        if (_profiles.value.any { it.id == id }) {
            _activeId.value = id
            persist()
        }
    }

    /** Stores connection results without touching anything else the user may be editing. */
    @Synchronized
    fun markConnected(id: String, endpoint: String?, mtu: Int?) {
        val p = get(id) ?: return
        upsert(
            p.copy(
                lastConnectedAt = System.currentTimeMillis(),
                lastGoodEndpoint = endpoint ?: p.lastGoodEndpoint,
                lastGoodMtu = mtu ?: p.lastGoodMtu,
            ),
        )
    }

    private fun persist() {
        val p = prefs ?: return
        runCatching {
            p.edit()
                .putString(KEY_PROFILES, json.encodeToString(_profiles.value))
                .putString(KEY_ACTIVE, _activeId.value)
                .apply()
        }.onFailure { AppLogger.e(TAG, "could not save profiles", it) }
    }
}

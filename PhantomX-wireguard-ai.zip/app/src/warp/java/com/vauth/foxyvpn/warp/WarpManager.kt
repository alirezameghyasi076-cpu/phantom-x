package com.vauth.foxyvpn.warp

import android.content.Context
import com.vauth.foxyvpn.data.AppLogger
import com.vauth.foxyvpn.vpn.IranianApps
import com.vauth.foxyvpn.wireguard.WgBackend
import com.vauth.foxyvpn.wireguard.WgConfigText
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import com.wireguard.crypto.KeyPair
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.util.concurrent.TimeUnit

enum class WarpStatus { IDLE, WORKING, CONNECTED, FAILED }

data class WarpUi(val status: WarpStatus, val message: String)

/**
 * Optional Cloudflare WARP / WireGuard tunnel that runs next to the normal Phantom X VPN.
 * Only one VPN can be active on Android, so starting one stops the other.
 */
object WarpManager {
    private const val TAG = "WarpManager"
    private const val PREFS = "phantom_warp"
    private const val DEFAULT_PEER_KEY = "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h2wPfgyo="

    private val endpoints = listOf(
        "162.159.192.1:2408",
        "162.159.193.1:2408",
        "188.114.97.1:2408",
        "188.114.98.1:2408",
        "162.159.192.1:500",
        "162.159.192.1:4500",
        "162.159.192.1:1701",
        "engage.cloudflareclient.com:2408",
        "162.159.192.1:854",
        "162.159.192.1:878",
        "162.159.192.1:894",
        "162.159.192.1:934",
        "162.159.192.1:987",
        "162.159.192.1:2506",
        "162.159.192.1:3581",
        "162.159.192.1:7152",
    )

    private data class Account(
        val privateKey: String,
        val address4: String,
        val address6: String?,
        val peerKey: String,
    )

    private val _ui = MutableStateFlow(WarpUi(WarpStatus.IDLE, "Free Cloudflare WARP tunnel"))
    val ui: StateFlow<WarpUi> = _ui.asStateFlow()

    @Volatile
    private var backend: GoBackend? = null

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val tunnel = object : Tunnel {
        override fun getName(): String = "phantomwarp"

        override fun onStateChange(newState: Tunnel.State) {
            if (newState == Tunnel.State.DOWN && _ui.value.status == WarpStatus.CONNECTED) {
                set(WarpStatus.IDLE, "Disconnected")
            }
        }
    }

    private fun set(status: WarpStatus, message: String) {
        _ui.value = WarpUi(status, message)
    }

    fun fail(message: String) {
        set(WarpStatus.FAILED, message)
    }

    private fun load(context: Context): Account? {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val priv = p.getString("priv", null) ?: return null
        val a4 = p.getString("a4", null) ?: return null
        return Account(priv, a4, p.getString("a6", null), p.getString("peer", null) ?: DEFAULT_PEER_KEY)
    }

    private fun save(context: Context, a: Account) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("priv", a.privateKey)
            .putString("a4", a.address4)
            .putString("a6", a.address6)
            .putString("peer", a.peerKey)
            .apply()
    }

    private fun register(): Account {
        val pair = KeyPair()
        val publicKey = pair.publicKey.toBase64()
        val privateKey = pair.privateKey.toBase64()
        val body = JSONObject()
            .put("key", publicKey)
            .put("install_id", "")
            .put("fcm_token", "")
            .put("tos", java.time.Instant.now().toString())
            .put("model", "PC")
            .put("serial_number", "")
            .put("locale", "en_US")
            .toString()
        val request = Request.Builder()
            .url("https://api.cloudflareclient.com/v0a2158/reg")
            .header("User-Agent", "okhttp/3.12.1")
            .header("CF-Client-Version", "a-6.10-2158")
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Cloudflare answered HTTP ${response.code}")
            val text = response.body?.string() ?: error("Empty answer from Cloudflare")
            val config = JSONObject(text).getJSONObject("config")
            val peerKey = config.getJSONArray("peers").getJSONObject(0).optString("public_key", DEFAULT_PEER_KEY)
            val addresses = config.getJSONObject("interface").getJSONObject("addresses")
            val v4 = addresses.getString("v4")
            val v6 = addresses.optString("v6", "").takeIf { it.isNotBlank() }
            return Account(privateKey, v4, v6, peerKey)
        }
    }

    private fun buildConfig(account: Account, endpoint: String, excluded: Set<String> = emptySet()): String {
        val addresses = buildString {
            append(account.address4).append("/32")
            if (account.address6 != null) append(", ").append(account.address6).append("/128")
        }
        return "[Interface]\n" +
            "PrivateKey = ${account.privateKey}\n" +
            "Address = $addresses\n" +
            "DNS = 1.1.1.1, 1.0.0.1\n" +
            "MTU = 1280\n" +
            (if (excluded.isNotEmpty()) "ExcludedApplications = ${excluded.sorted().joinToString(", ")}\n" else "") +
            "\n[Peer]\n" +
            "PublicKey = ${account.peerKey}\n" +
            "AllowedIPs = 0.0.0.0/0, ::/0\n" +
            "Endpoint = $endpoint\n" +
            "PersistentKeepalive = 25\n"
    }

    private suspend fun gotReply(be: GoBackend, seconds: Int): Boolean {
        repeat(seconds * 2) {
            val rx = runCatching { be.getStatistics(tunnel).totalRx() }.getOrDefault(0L)
            if (rx > 0L) return true
            delay(500)
        }
        return false
    }

    /** Connects WARP, or the pasted WireGuard config when [customConfig] is given. */
    suspend fun connect(context: Context, customConfig: String? = null) = withContext(Dispatchers.IO) {
        val app = context.applicationContext
        set(WarpStatus.WORKING, "Preparing\u2026")
        try {
            val be = WgBackend.get(app).also { backend = it }
            if (customConfig != null) {
                if (customConfig.isBlank()) {
                    set(WarpStatus.FAILED, "Paste a WireGuard config first")
                    return@withContext
                }
                val cfg = Config.parse(ByteArrayInputStream(withIranianBypass(app, customConfig).toByteArray()))
                be.setState(tunnel, Tunnel.State.UP, cfg)
                if (gotReply(be, 10)) {
                    set(WarpStatus.CONNECTED, "Connected with your WireGuard config")
                } else {
                    be.setState(tunnel, Tunnel.State.DOWN, null)
                    set(WarpStatus.FAILED, "The server did not answer. Check the config.")
                }
                return@withContext
            }

            var account = load(app)
            if (account == null) {
                set(WarpStatus.WORKING, "Creating a free WARP account\u2026")
                account = register()
                save(app, account)
            }

            val iranianApps = IranianApps.forTunnel(app)
            for (endpoint in endpoints) {
                set(WarpStatus.WORKING, "Trying $endpoint\u2026")
                val cfg = Config.parse(ByteArrayInputStream(buildConfig(account, endpoint, iranianApps).toByteArray()))
                be.setState(tunnel, Tunnel.State.UP, cfg)
                if (gotReply(be, 6)) {
                    AppLogger.i(TAG, "WARP connected via $endpoint")
                    set(WarpStatus.CONNECTED, "Connected via $endpoint")
                    return@withContext
                }
                be.setState(tunnel, Tunnel.State.DOWN, null)
            }
            set(WarpStatus.FAILED, "No WARP endpoint answered. Try another network.")
        } catch (t: Throwable) {
            AppLogger.e(TAG, "WARP connect failed", t)
            runCatching { backend?.setState(tunnel, Tunnel.State.DOWN, null) }
            set(WarpStatus.FAILED, "Failed: ${t.message ?: t.javaClass.simpleName}")
        }
    }

    /** Adds the Iranian-app exclusion to a pasted config unless it already has its own app list. Never throws. */
    private fun withIranianBypass(app: Context, text: String): String = runCatching {
        val parsed = WgConfigText.parse(text)
        val iface = parsed.iface
        if (iface == null || iface.has("ExcludedApplications") || iface.has("IncludedApplications")) {
            text
        } else {
            val apps = IranianApps.forTunnel(app)
            if (apps.isEmpty()) {
                text
            } else {
                iface.set("ExcludedApplications", apps.sorted().joinToString(", "))
                parsed.toText()
            }
        }
    }.getOrDefault(text)

    /** Cumulative (received, sent) bytes of the running WARP tunnel, or null when it is not up. */
    fun totals(): Pair<Long, Long>? {
        if (_ui.value.status != WarpStatus.CONNECTED) return null
        val stats = runCatching { backend?.getStatistics(tunnel) }.getOrNull() ?: return null
        return runCatching { stats.totalRx() to stats.totalTx() }.getOrNull()
    }

    suspend fun disconnect() = withContext(Dispatchers.IO) {
        runCatching { backend?.setState(tunnel, Tunnel.State.DOWN, null) }
        set(WarpStatus.IDLE, "Disconnected")
    }
}

package com.vauth.foxyvpn.wireguard

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import com.wireguard.config.BadConfigException
import com.wireguard.config.Config
import com.wireguard.config.InetNetwork
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.URL
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

enum class DiagLevel { OK, INFO, WARN, ERROR }

data class DiagItem(
    val level: DiagLevel,
    val title: String,
    val detail: String = "",
    val fix: String = "",
)

data class ProbeResult(val ipOk: Boolean, val dnsOk: Boolean, val httpsOk: Boolean, val items: List<DiagItem>)

/** Checks that explain, in plain words, why a WireGuard tunnel does not work. Nothing here logs or returns key material. */
object WgDiagnostics {

    private val pool = Executors.newCachedThreadPool { r -> Thread(r, "wg-diag").apply { isDaemon = true } }

    /** Runs a blocking call with a hard time limit (DNS lookups on Android cannot be given a timeout). */
    fun <T> withTimeout(ms: Long, block: () -> T): T? {
        val f = pool.submit(Callable { runCatching(block).getOrNull() })
        return try {
            f.get(ms, TimeUnit.MILLISECONDS)
        } catch (t: Throwable) {
            f.cancel(true)
            null
        }
    }

    fun resolve(host: String, timeoutMs: Long = 5000): List<InetAddress> {
        // Literal addresses never hit DNS.
        if (host.all { it.isDigit() || it == '.' } || host.contains(':')) {
            return withTimeout(timeoutMs) { listOf(InetAddress.getByName(host)) }.orEmpty()
        }
        return withTimeout(timeoutMs) { InetAddress.getAllByName(host).toList() }.orEmpty()
    }

    fun explain(e: BadConfigException): DiagItem {
        val where = buildString {
            append(e.section.name.lowercase().replaceFirstChar { it.uppercase() })
            append(" \u203A ").append(e.location.name.lowercase().replace('_', ' '))
        }
        val text = e.text?.takeIf { it.isNotBlank() }?.let { shorten(it) }
        val (what, fix) = when (e.reason.name) {
            "INVALID_KEY" -> "A key is not valid base64 (it must be 44 characters ending with =)." to
                "Copy the key again without spaces or line breaks."
            "INVALID_NUMBER" -> "A number is not valid." to "Check the value for a typo."
            "INVALID_VALUE" -> "This value is not accepted." to "Check the format, for example 10.0.0.2/32 for Address or host:51820 for Endpoint."
            "MISSING_ATTRIBUTE" -> "A required setting is missing." to
                "Interface needs PrivateKey; every Peer needs PublicKey."
            "MISSING_SECTION" -> "A required section is missing." to "The config needs one [Interface] and at least one [Peer] section."
            "SYNTAX_ERROR" -> "A line is not in the form Key = Value." to "Fix or remove the line."
            "UNKNOWN_ATTRIBUTE" -> "This setting is not supported on Android." to "Remove the line."
            "UNKNOWN_SECTION" -> "This section name is not supported." to "Only [Interface] and [Peer] exist."
            else -> "The config could not be read." to "Compare it with the file you received."
        }
        return DiagItem(DiagLevel.ERROR, "Config error: $where", what + (text?.let { "  \u201C$it\u201D" } ?: ""), fix)
    }

    private fun shorten(s: String): String {
        val t = s.trim()
        // Never echo anything that could be a key.
        if (t.length >= 40 && t.none { it == ' ' }) return WgKeys.mask(t)
        return if (t.length > 60) t.take(57) + "\u2026" else t
    }

    /** Offline checks on a parsed config. */
    fun staticChecks(text: WgConfigText, cfg: Config): List<DiagItem> {
        val out = mutableListOf<DiagItem>()
        val iface = cfg.getInterface()
        val peers = cfg.getPeers()

        val ownPublic = WgKeys.publicKeyOf(text)
        if (peers.isEmpty()) {
            out += DiagItem(DiagLevel.ERROR, "No peer", "The config has no [Peer] section.", "Add the server as a [Peer].")
        }
        if (ownPublic != null && peers.any { it.publicKey.toBase64() == ownPublic }) {
            out += DiagItem(
                DiagLevel.ERROR, "Server key equals your key",
                "The Peer PublicKey is the public key of your own PrivateKey.",
                "PublicKey must be the SERVER's public key, not yours.",
            )
        }
        if (iface.addresses.isEmpty()) {
            out += DiagItem(DiagLevel.WARN, "No Address", "The interface has no address, so no traffic can be routed through it.", "Add Address = 10.x.x.x/32 as given by your provider.")
        }
        for (peer in peers) {
            if (!peer.endpoint.isPresent) {
                out += DiagItem(DiagLevel.WARN, "Peer without Endpoint", "The tunnel cannot start the connection without the server address.", "Add Endpoint = host:port.")
            }
            if (peer.allowedIps.isEmpty()) {
                out += DiagItem(DiagLevel.WARN, "Empty AllowedIPs", "No traffic will go through this peer.", "Use 0.0.0.0/0, ::/0 to send everything through the tunnel.")
            }
        }
        val mtu = iface.mtu.orElse(null)
        if (mtu != null && (mtu < 1200 || mtu > 1500)) {
            out += DiagItem(DiagLevel.WARN, "Unusual MTU ($mtu)", "Values outside 1200\u20131500 often break connections.", "Use 1280 for restrictive networks or 1420 for speed.")
        }
        if (isFullTunnel(cfg) && iface.dnsServers.isEmpty()) {
            out += DiagItem(DiagLevel.WARN, "No DNS server", "All traffic is tunnelled but DNS is not set; names may fail or leak to your ISP.", "Add DNS = 1.1.1.1 (or the server's DNS).")
        }
        if (text.notes.isNotEmpty()) {
            out += DiagItem(DiagLevel.INFO, "Adjusted for Android", text.notes.joinToString("\n"))
        }
        return out
    }

    fun isFullTunnel(cfg: Config): Boolean =
        cfg.getPeers().any { p -> p.allowedIps.any { it.mask == 0 } }

    /** True when [address] would be routed through the tunnel. IPv4 only, which is all the probes use. */
    fun isRouted(cfg: Config, address: InetAddress): Boolean {
        val raw = address.address
        if (raw.size != 4) return false
        return cfg.getPeers().any { p -> p.allowedIps.any { net -> covers(net, raw) } }
    }

    private fun covers(net: InetNetwork, ip: ByteArray): Boolean {
        val base = net.address.address
        if (base.size != 4) return false
        var bits = net.mask
        for (i in 0 until 4) {
            if (bits <= 0) break
            val m = if (bits >= 8) 0xFF else (0xFF shl (8 - bits)) and 0xFF
            if ((base[i].toInt() and m) != (ip[i].toInt() and m)) return false
            bits -= 8
        }
        return true
    }

    /** A real network (Wi-Fi, mobile, ethernet) with internet, ignoring any VPN that is currently active. */
    @Suppress("DEPRECATION")
    fun hasUnderlyingNetwork(context: Context): Boolean {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return true
        return cm.allNetworks.any {
            val c = cm.getNetworkCapabilities(it) ?: return@any false
            c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                !c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
        }
    }

    @Suppress("DEPRECATION")
    fun vpnNetwork(context: Context): Network? {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return null
        return cm.allNetworks.firstOrNull {
            cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
        }
    }

    /**
     * After the handshake: is traffic really flowing? Splits the answer into raw IP, DNS and a TLS fetch
     * (the TLS certificate chain needs full-size packets, so it also reveals MTU problems).
     */
    fun probeTunnel(context: Context): ProbeResult {
        val net = vpnNetwork(context)
        val items = mutableListOf<DiagItem>()

        val ipOk = withTimeout(5000) {
            val socket = (net?.socketFactory ?: javax.net.SocketFactory.getDefault()).createSocket()
            socket.use { it.connect(InetSocketAddress("1.1.1.1", 443), 4000) }
            true
        } == true
        items += if (ipOk) DiagItem(DiagLevel.OK, "Traffic passes through the tunnel", "Reached 1.1.1.1 over the tunnel.")
        else DiagItem(
            DiagLevel.ERROR, "Handshake works but no traffic passes",
            "The server answered, yet a connection to 1.1.1.1 failed.",
            "On the server: enable IP forwarding and NAT/masquerade, and make sure this client's tunnel address is in its AllowedIPs.",
        )

        val dnsOk = ipOk && withTimeout(6000) {
            if (net != null) net.getAllByName("cloudflare.com").isNotEmpty() else InetAddress.getAllByName("cloudflare.com").isNotEmpty()
        } == true
        if (ipOk) {
            items += if (dnsOk) DiagItem(DiagLevel.OK, "DNS works")
            else DiagItem(
                DiagLevel.WARN, "DNS does not answer",
                "IP traffic works but name lookups fail.",
                "Set DNS = 1.1.1.1 in the Interface, or use the DNS server your provider gave you.",
            )
        }

        var httpsOk = false
        if (ipOk) {
            httpsOk = withTimeout(9000) {
                val url = URL("https://1.1.1.1/cdn-cgi/trace")
                val conn = (net?.openConnection(url) ?: url.openConnection()) as HttpURLConnection
                conn.connectTimeout = 5000
                conn.readTimeout = 6000
                conn.instanceFollowRedirects = false
                try {
                    conn.responseCode in 200..399
                } finally {
                    conn.disconnect()
                }
            } == true
            items += if (httpsOk) DiagItem(DiagLevel.OK, "Large packets pass (MTU ok)")
            else DiagItem(
                DiagLevel.WARN, "Large packets are lost",
                "Small connections work but a TLS handshake failed. This is the typical sign of an MTU that is too high.",
                "Set MTU = 1280 in the Interface (the app retries with 1280 automatically).",
            )
        }
        return ProbeResult(ipOk, dnsOk, httpsOk, items)
    }

    /** Turns a backend failure into something a person can act on. */
    fun explainBackend(reason: String?, message: String?): DiagItem = when (reason) {
        "VPN_NOT_AUTHORIZED" -> DiagItem(DiagLevel.ERROR, "VPN permission missing", "Android has not allowed this app to create a VPN.", "Tap Connect again and accept the system dialog.")
        "DNS_RESOLUTION_FAILURE" -> DiagItem(DiagLevel.ERROR, "Server name cannot be resolved", "The Endpoint host name did not resolve.", "Check the host name, or put the server's IP address in Endpoint.")
        "TUN_CREATION_ERROR" -> DiagItem(DiagLevel.ERROR, "Could not create the tunnel interface", "Android refused the VPN interface (Address or routes invalid, or another VPN is in lockdown).", "Check Address, and turn off \u201CBlock connections without VPN\u201D for another VPN app.")
        "UNABLE_TO_START_VPN" -> DiagItem(DiagLevel.ERROR, "Android could not start the VPN service", "Another VPN app may be blocking it or the system is low on resources.", "Disconnect other VPN apps and retry.")
        "GO_ACTIVITY_NOT_FOUND", "UNKNOWN_KERNEL_MODULE_NAME", "WG_QUICK_CONFIG_ERROR_CODE", "TUNNEL_MISSING_CONFIG" ->
            DiagItem(DiagLevel.ERROR, "WireGuard engine error", reason, "Restart the app and try again.")
        else -> DiagItem(DiagLevel.ERROR, "Tunnel could not start", message ?: reason.orEmpty(), "Check the config and try again.")
    }

    fun noHandshakeAdvice(tried: List<String>): DiagItem = DiagItem(
        DiagLevel.ERROR, "The server did not answer",
        "No handshake after trying ${tried.size} endpoint(s): ${tried.joinToString(", ")}.",
        "Most common causes: (1) the UDP port is blocked on this network, try mobile data or another Wi-Fi; " +
            "(2) the server does not know your public key (add it as a peer on the server); " +
            "(3) wrong server PublicKey or Endpoint; (4) the server is down. " +
            "You can add fallback endpoints (other ports such as 443 or 53) in the profile settings.",
    )

    /** Plain text report for sharing. Contains no keys and no full config. */
    fun report(profileName: String?, state: String, message: String, items: List<DiagItem>): String = buildString {
        append("Phantom X WireGuard report\n")
        append("Profile: ").append(profileName ?: "-").append('\n')
        append("State: ").append(state).append(" \u2013 ").append(message).append('\n')
        append("Android: ").append(android.os.Build.VERSION.RELEASE).append(" (API ").append(android.os.Build.VERSION.SDK_INT).append(")\n\n")
        for (i in items) {
            append('[').append(i.level.name).append("] ").append(i.title).append('\n')
            if (i.detail.isNotBlank()) append("    ").append(i.detail.replace("\n", "\n    ")).append('\n')
            if (i.fix.isNotBlank()) append("    Fix: ").append(i.fix).append('\n')
        }
    }
}

package com.vauth.foxyvpn.ui

import android.os.SystemClock
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import com.vauth.foxyvpn.extra.ExtraStatus
import com.vauth.foxyvpn.extra.ExtraTunnelManager
import com.vauth.foxyvpn.vpn.tun.HevSocks5Tunnel
import com.vauth.foxyvpn.warp.WarpManager
import com.vauth.foxyvpn.warp.WarpStatus
import com.vauth.foxyvpn.wireguard.WgManager
import com.vauth.foxyvpn.wireguard.WgState

/** True while WARP, a WireGuard profile or a share-link tunnel is connected (WARP build). */
@Composable
fun extraTunnelConnected(): Boolean {
    val wg by WgManager.ui.collectAsState()
    val warp by WarpManager.ui.collectAsState()
    val extra by ExtraTunnelManager.ui.collectAsState()
    return wg.state == WgState.CONNECTED ||
        warp.status == WarpStatus.CONNECTED ||
        extra.status == ExtraStatus.CONNECTED
}

/** Turns ever-growing byte counters into bytes/second. Restarts cleanly when the source changes. */
private class RateTracker {
    private var source = ""
    private var lastRx = 0L
    private var lastTx = 0L
    private var lastAt = 0L

    fun rates(name: String, rx: Long, tx: Long): Pair<Long, Long> {
        val now = SystemClock.elapsedRealtime()
        if (name != source) {
            source = name
            lastRx = rx
            lastTx = tx
            lastAt = now
            return 0L to 0L
        }
        val dt = (now - lastAt).coerceAtLeast(1L)
        val down = (rx - lastRx).coerceAtLeast(0L) * 1000L / dt
        val up = (tx - lastTx).coerceAtLeast(0L) * 1000L / dt
        lastRx = rx
        lastTx = tx
        lastAt = now
        return down to up
    }
}

/** Current (download, upload) bytes/second of whichever extra tunnel is connected. */
@Composable
fun rememberExtraTunnelSampler(): () -> Pair<Long, Long> {
    val tracker = remember { RateTracker() }
    return remember<() -> Pair<Long, Long>> {
        {
            when {
                // WireGuard already measures its own rates every second.
                WgManager.ui.value.state == WgState.CONNECTED -> {
                    val s = WgManager.ui.value.stats
                    s.rxRate to s.txRate
                }
                WarpManager.ui.value.status == WarpStatus.CONNECTED ->
                    WarpManager.totals()?.let { tracker.rates("warp", it.first, it.second) } ?: (0L to 0L)
                ExtraTunnelManager.ui.value.status == ExtraStatus.CONNECTED -> {
                    val s = HevSocks5Tunnel.stats()
                    // hev-socks5-tunnel: [tx packets, tx bytes, rx packets, rx bytes]
                    tracker.rates("extra", s.getOrElse(3) { 0L }, s.getOrElse(1) { 0L })
                }
                else -> 0L to 0L
            }
        }
    }
}

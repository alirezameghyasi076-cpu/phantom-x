package com.vauth.foxyvpn.ui

import androidx.compose.runtime.Composable

private val NO_TRAFFIC: () -> Pair<Long, Long> = { 0L to 0L }

/** The standard build has no extra tunnels. The WARP build replaces this with the real check. */
@Composable
fun extraTunnelConnected(): Boolean = false

@Composable
fun rememberExtraTunnelSampler(): () -> Pair<Long, Long> = NO_TRAFFIC
